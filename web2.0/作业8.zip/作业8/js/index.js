/* 本地校验 */
window.onload = function() {
	var text = document.getElementsByClassName('text');
	var tip = document.getElementById('tip');
	for (var i = 0; i < text.length; i++) {
		text[i].onblur = function() {
			var value = this.value, name = this.name;
			if (value == "")
				return;
			if (name == "username") {
				if (/\W/.test(value) || /[a-zA-Z]\w{5,17}/.test(value) == false || value.length > 18 || /[a-zA-Z]/.test((value)[0]) == false)
					tip.textContent =  "Sorry, your username is invalid!";
				else
					tip.textContent = "";
			}
			if (name == "id") {
				if (/\D/.test(value) || (value)[0] == '0' || /\d{8}/.test(value) == false || value.length > 8)
					tip.textContent = "Sorry, your student id is invalid!";
				else
					tip.textContent = "";
			}
			if (name == "tel") {
				if (/\D/.test(value) || (value)[0] == '0' || /\d{11}/.test(value) == false || value.length > 11)
					tip.textContent = "Sorry, your telephone number is invalid!";
				else
					tip.textContent = "";
			}
			if (name == "email") {
				if (/^[a-zA-Z_0-9\-]+@(([a-zA-Z_0-9\-])+\.)+[a-zA-Z]{2,4}$/.test(value) == false)
					tip.textContent = "Sorry, your email address is invalid!";
				else
					tip.textContent = "";
			}
		}
	};
}