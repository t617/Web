$(function () {
  var tableObject_todo = $('#todo'); //对两个table选择进行排序
  var tableObject_staff = $('#staff');
  tablesort(tableObject_todo);
  tablesort(tableObject_staff);
})
function tablesort(tableObject) {
  var tbHeadTh = tableObject.children('thead').find('tr th'); //获取thead下的tr下的th
  var tbBodyTr = tableObject.children('tbody').find('tr'); //获取tbody下的tr
  var ascend = "<img src='img/ascend.png' alt='ascend'/>";
  var descend = "<img src='img/descend.png' alt='descend'/>";
  var th_innerHTML = new Array();
  var sortIndex = -1;

  change_inner(tbHeadTh, th_innerHTML, ascend, descend, checkColumnValue); //改变th的样式

  function checkColumnValue(index) {  //对选择的列排序后调整
    var trsValue = new Array();

    tbBodyTr.each(function () {
      var tds = $(this).find('td');
      trsValue.push($(tds[index]).html() + "separator" + $(this).html());
    });

    var len = trsValue.length;
    if (index == sortIndex) {
      trsValue.reverse();
    } else {
      sort(trsValue, len);
    }
    var i = 0;

    tbBodyTr.each(function () {
      $(this).html(trsValue[i].split("separator")[1]);
      i++;
    });

    sortIndex = index;
  }
}
function change_inner(tbHeadTh, th_innerHTML, ascend, descend, checkColumnValue) {

  tbHeadTh.each(function () {
    var thisIndex = tbHeadTh.index($(this));
    th_innerHTML[thisIndex] = tbHeadTh[thisIndex].innerHTML;
  });

  tbHeadTh.each(function () {
    var flag = true;
    var thisIndex = tbHeadTh.index($(this));
    change_p(th_innerHTML, tbHeadTh, thisIndex, ascend)

    $(this).click(function () { //三角图片的变化
      if (flag == true) change_p(th_innerHTML, tbHeadTh, thisIndex, ascend);
      else change_p(th_innerHTML, tbHeadTh, thisIndex, descend);
      flag = !flag;
      checkColumnValue(thisIndex);
    });

  });
}

function sort(trsValue, len) { //冒泡排序
  for (var i = 0; i < len; i++) {
    for (var j = i + 1; j < len; j++) {
      var value1 = trsValue[i].split("separator")[0];
      var value2 = trsValue[j].split("separator")[0];
      if (value1 > value2) {
        var temp = trsValue[j];
        trsValue[j] = trsValue[i];
        trsValue[i] = temp;
      }
    }
  }
}

function change_p(th_inner, g_th, index, scend) { //改变图片
  g_th[index].innerHTML = th_inner[index] + scend;
}
