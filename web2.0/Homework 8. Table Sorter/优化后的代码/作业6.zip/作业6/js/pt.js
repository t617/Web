/* By Song Zhiqiang */
$(function() {
  /* 动态创建16个div */
  var d = document.createDocumentFragment();
  for (var i = 1; i < 17; i++) {
    var div = document.createElement("div");
    div.id = "pt" + i;
    div.className = "position" + i;
    d.appendChild(div);
  }
  $('#pin_tu').append(d);
  /*点击移动*/
  click_div();
  $('#start').click(function() {
    start_p();
  });
  $('#reset').click(function() {
    reset_p();
  });
})
function click_div() {
  for (var i = 0; i < 16; i++) {
    (function(i) {
      $('#pt' + (i + 1)).click(function() {
        if (is_near(i)) {
          var temp_name = $('#pt1').attr('class');
          $('#pt1').attr('class', $(this).attr('class'));
          $(this).attr('class', temp_name);
          var c = random[0];
          random[0] = random[i];
          random[i] = c;
        }
        if (is_succeed()) {
          $('#is_s').text("已还原拼图!");
        } else {
          $('#is_s').text("加油，还差一点哦!");
        }
      });
    })(i);
  }
}
/* 判断是否拼好 */
function is_succeed() {
  for (var i = 0; i < 16; i++) {
    if ((i + 1)!=random[i]) {
      return false;
    }
  }
  return true;
}
/* 判断能否移动 */
function is_near(k) {
  up = random[k] - 4;
  down = random[k] + 4;
  left = random[k] - 1;
  right = random[k] + 1;
  if ((up>0&&random[0]==up)||(down<17&&random[0]==down)||(random[k]%4!=1&&random[0]==left)||(random[k]%4!=0&&random[0]==right)) {
    return true;
  }
}
/* 随机数组生成 */
function my_ran(n, min, max) {
 var arr = [];
 for(var i = 0; i < n; i++) {
  arr[i] = _.random(min, max);
  for(j = 0; j < i; j++) {
   if(arr[i] == arr[j]) {
    i = i - 1;
    break;
   }
  }
 }
 return arr;
}
/* 开始拼图 */
function start_p() {
  $('#is_s').text("开始拼图吧!");
  random = my_ran(16, 1, 16);
  for (var i = 0; i < 16; i++) {
    $('#pt' + (i + 1)).attr('class', 'position' + random[i]);
  }
}
/* 还原拼图 */
function reset_p() {
  $('#is_s').text("已还原拼图!");
  for (var i = 0; i < 16; i++) {
    random[i] = i + 1;
    $('#pt' + (i + 1)).attr('class', 'position' + (i + 1));
  }
}