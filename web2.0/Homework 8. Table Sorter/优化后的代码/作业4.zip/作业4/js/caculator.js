/* 临时初始变量 */
$(function() {
  flag=true;
  input_sreeen = $('#input_sreeen');
  var keys = $('#keys');
  var keys_inputs = keys.find('input');
  keys_inputs.each(function() {
    $(this).click(function() {
      if ($(this).attr('id') == 'CE') { Clear(); }
      else if ($(this).attr('id') == "<-") { Back(); }
      else if($(this).attr('id') == '=') { eva(); }
      else { jsq($(this).attr('id')); }
    });
  });
})
/* 表达式相加 */
function jsq(formula) {
  var formula_d = document.getElementById(formula);
  //alert(formula_d.val());
  if (flag==true||(formula=='+'||formula=='-'||formula=='*'||formula=='/')&&flag==false) {
    input_sreeen.val(input_sreeen.val() + formula_d.value);
    flag=true;
  } else {
    Clear();
    input_sreeen.val(input_sreeen.val() + formula_d.value);
    flag=true;
  }
}
/* eval函数求出值并可以抛出异常 */
function eva() {
  try {
    flag=false;
    input_sreeen.val(eval(input_sreeen.val()));
  }
  catch(exception) {
    alert(exception);
  }
}
/* 清屏 */
function Clear() {
  input_sreeen.val(null);
  input_sreeen.focus();
}
/* 退格截断最后一个字符 */
function Back() {
  input_sreeen.val(input_sreeen.val().substring(0, input_sreeen.val().length - 1));
}